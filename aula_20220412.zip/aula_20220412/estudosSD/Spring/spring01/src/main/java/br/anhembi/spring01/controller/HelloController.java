package br.anhembi.spring01.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//A anotação sempre vai em cima do que ele esta anotando e ela é fundamental para o funcionamento do programa

@RestController
//Para não acontecer um bloqueio de acesso cujo dominio seja diferente do dominio que vc está acessando
@CrossOrigin("*") // Ou seja, aceita requisições de qualquer domínio
//Para a requisição precisamos do protocolo, servidor, porta (se for o caso), recurso.
@RequestMapping ("/hello") //geralmente esse e o nome que usamos para acessar a classe

public class HelloController { 

    @GetMapping // preciso dizer que tipo de requisição eu vou fazer
    public String ola(){
        return "Boa noite!";
        }
/*SPRING BOOT DASHBOARD:
RETORNO: 2022-04-12 20:40:57.432  INFO 7392 --- [nio-8080-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/]: Initializing Spring DispatcherServlet 'dispatcherServlet'
Aplicação está rodando, em cima do Tomcat na porta 8080. URL http://localhost:8080/hello para testar */

@GetMapping("/noite")
        public String ola2(){
            return "Olá! Boa noite";
        }
    }

