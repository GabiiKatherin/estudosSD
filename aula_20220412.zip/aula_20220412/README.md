<h1>Anotações das aulas de Sistemas Distribuídos
<h2>Separados por dia de aula

<h3> - 20221204 - REST (Representation State Transfer):

<ul>
 <b>1:</b> Interface Uniforme
 <b>2:</b> Modelo Cliente-Servidor
 <b>3:</b> Sem Estado (Stateless): Não podemos acreditar que o servidor guardará as infos das requisições
 <b>4:</b> Cacheable
 <b>5:</b> Em camadas (Layered): Na situação e que temos um banco de dados, em orientação a objetos, temos uma classe responsável pela interface (acesso com o cliente), processamento dos dados, outra classe para o acesso aos dados e cada camada tem uma responsabilidade diferente. Referência ao modelo MVC.
 <b>6:</b> (Opcional) Code On Demand: O servidor pode devolver pro cliente algo que o cliente irá processar, ao invés do servidor rodar.
</ul>

Desenvolvimento em camadas:

<b>Controller</b>: camada de acesso -> View: apresentação para o cliente
   <b>Services</b>: regras do negócio
     <b>Model</b>: modelo de dados - acesso aos dados/DAO: Dataset object

Front-end <-requisição & resposta-> back-end
<b>Servidor (TomCat) -> App Java <--> Servior de BD</b>

Usaremos um framework que vai facilitar a aplicação, mas o foco é no back-end: Spring Boot + JPA (Java Persistence API) para definir uma meio de Object-Relational Mapping para objetos java simples e comuns (POJOs)

- Instalação do Spring Boot Extension Pack:
dependências incluídas: Spring Web e Spring Boot Dev Tools

"Lembrando que o que será compilado precisa estar em uma janela separada porque o projeto precisa ser desenvolvido e compilado de forma independente, porém, as commits estão sendo feitos na janela aberta anteriormente."

O Spring Boot criará um pasta server, main e test
-> Depois de criado o HelloController, ir no browser e inserir a URL http://localhost:8080/hello para testar :)